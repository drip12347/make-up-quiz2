const questions=[
 {id:1,question:"What is the output of 2 + 3?",options:["4","5","23","6"],answerIndex:1},
 {id:2,question:"Which language is for web page structure?",options:["CSS","HTML","Python","C++"],answerIndex:1},
 {id:3,question:"Paragraph tag in HTML?",options:["<para>","<p>","<pr>","<paragraph>"],answerIndex:1},
 {id:4,question:"React is for building:",options:["DB","UI","Kernel","Spreadsheets"],answerIndex:1},
 {id:5,question:"CSS stands for:",options:["Computer Style Sheets","Cascading Style Sheets","Control Style Scripts","Colorful Style Sheets"],answerIndex:1}
];
export default questions;